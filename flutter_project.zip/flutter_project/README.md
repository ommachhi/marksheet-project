# Flutter Fruit App

A comprehensive Flutter mobile application with authentication and fruit management features using Firebase.

## Features

- **Authentication**: Login and registration with Firebase Authentication
- **Dashboard**: Main navigation hub with user information
- **Fruit Management**: Complete CRUD operations for fruit items
- **Fruit List**: Display all fruits with images and descriptions
- **Fruit Details**: Detailed view of individual fruits
- **State Management**: Provider pattern for efficient state management
- **Clean Architecture**: Repository pattern with service layers

## Screens

1. **Login Screen**: User authentication
2. **Registration Screen**: New user signup
3. **Dashboard Screen**: Main navigation hub
4. **Fruit List Screen**: Display all fruits with CRUD operations
5. **Fruit Detail Screen**: Detailed fruit information
6. **Add/Edit Fruit Screen**: Create and update fruit items

## Tech Stack

- **Flutter**: Cross-platform mobile development
- **Firebase**: Authentication and Firestore database
- **Provider**: State management
- **GoRouter**: Navigation
- **Cached Network Image**: Image loading and caching
- **Material Design**: UI components

## Setup Instructions

### Prerequisites

- Flutter SDK (3.0.0 or higher)
- Android Studio / VS Code
- Firebase project

### 1. Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project named "flutter-fruit-app"
3. Enable Authentication:
   - Go to Authentication > Sign-in method
   - Enable Email/Password authentication
4. Enable Firestore Database:
   - Go to Firestore Database
   - Create database in test mode
5. Download configuration files:
   - For Android: Download `google-services.json` and place in `android/app/`
   - For iOS: Download `GoogleService-Info.plist` and place in `ios/Runner/`

### 2. Project Setup

1. Clone or download the project
2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Update Firebase configuration:
   - Replace the dummy `google-services.json` with your actual file
   - Replace the dummy `GoogleService-Info.plist` with your actual file

### 3. Run the App

```bash
flutter run
```

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/                   # Data models
│   ├── user_model.dart
│   └── fruit_model.dart
├── services/                 # API services
│   ├── auth_service.dart
│   └── fruit_service.dart
├── providers/                # State management
│   ├── auth_provider.dart
│   └── fruit_provider.dart
└── screens/                  # UI screens
    ├── login_screen.dart
    ├── registration_screen.dart
    ├── dashboard_screen.dart
    ├── fruit_list_screen.dart
    ├── fruit_detail_screen.dart
    └── add_edit_fruit_screen.dart
```

## Features Overview

### Authentication
- Email/password authentication
- User registration with display name
- Automatic login state management
- Secure logout functionality

### Fruit Management
- **Create**: Add new fruits with all details
- **Read**: View fruit list and individual details
- **Update**: Edit existing fruit information
- **Delete**: Remove fruits with confirmation

### UI/UX
- Material Design 3 components
- Responsive layout
- Loading states and error handling
- Image caching for better performance
- Intuitive navigation flow

## Database Schema

### Users Collection
```json
{
  "id": "user_id",
  "email": "user@example.com",
  "displayName": "User Name",
  "photoURL": "https://..."
}
```

### Fruits Collection
```json
{
  "name": "Apple",
  "description": "A red, crisp fruit",
  "imageUrl": "https://example.com/apple.jpg",
  "nutrition": "Rich in fiber and vitamin C",
  "origin": "United States",
  "season": "Fall",
  "createdAt": "2024-01-01T00:00:00Z",
  "updatedAt": "2024-01-01T00:00:00Z"
}
```

## Development Notes

- The app uses Provider for state management
- All API calls are handled through service classes
- Error handling is implemented throughout the app
- The UI follows Material Design guidelines
- Images are cached for better performance

## Troubleshooting

1. **Firebase connection issues**: Ensure configuration files are correctly placed
2. **Build errors**: Run `flutter clean` and `flutter pub get`
3. **Authentication issues**: Check Firebase Authentication settings
4. **Database errors**: Verify Firestore rules and permissions

## Future Enhancements

- User profile management
- Fruit categories and filtering
- Offline support
- Push notifications
- Social sharing features
- Advanced search functionality

