import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:go_router/go_router.dart';

import 'firebase_options.dart';

import 'providers/auth_provider.dart';
import 'providers/fruit_provider.dart';
import 'services/auth_service.dart';
import 'services/mock_auth_service.dart';
import 'services/fruit_service.dart';
import 'services/mock_fruit_service.dart';
import 'screens/login_screen.dart';
import 'screens/registration_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/fruit_list_screen.dart';
import 'screens/fruit_detail_screen.dart';
import 'screens/add_edit_fruit_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase only on non-web to avoid missing web config
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (_) {}
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => AuthProvider(kIsWeb ? MockAuthService() : AuthService()),
        ),
        ChangeNotifierProvider(
          create: (context) => FruitProvider(kIsWeb ? MockFruitService() : FruitService()),
        ),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, authProvider, child) {
          return MaterialApp.router(
            title: 'Fruit App',
            theme: ThemeData(
              primarySwatch: Colors.green,
              useMaterial3: true,
            ),
            routerConfig: _createRouter(authProvider),
          );
        },
      ),
    );
  }

  GoRouter _createRouter(AuthProvider authProvider) {
    return GoRouter(
      initialLocation: authProvider.isAuthenticated ? '/dashboard' : '/login',
      redirect: (context, state) {
        final isAuthenticated = authProvider.isAuthenticated;
        final isLoggingIn = state.matchedLocation == '/login' || 
                           state.matchedLocation == '/register';

        if (!isAuthenticated && !isLoggingIn) {
          return '/login';
        }
        if (isAuthenticated && isLoggingIn) {
          return '/dashboard';
        }
        return null;
      },
      routes: [
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginScreen(),
        ),
        GoRoute(
          path: '/register',
          builder: (context, state) => const RegistrationScreen(),
        ),
        GoRoute(
          path: '/dashboard',
          builder: (context, state) => const DashboardScreen(),
        ),
        GoRoute(
          path: '/fruits',
          builder: (context, state) => const FruitListScreen(),
        ),
        // Put specific routes BEFORE parameterized '/fruit/:id'
        GoRoute(
          path: '/fruit/add',
          builder: (context, state) => const AddEditFruitScreen(),
        ),
        GoRoute(
          path: '/fruit/edit/:id',
          builder: (context, state) {
            final fruitId = state.pathParameters['id']!;
            return AddEditFruitScreen(fruitId: fruitId);
          },
        ),
        GoRoute(
          path: '/fruit/:id',
          builder: (context, state) {
            final fruitId = state.pathParameters['id']!;
            return FruitDetailScreen(fruitId: fruitId);
          },
        ),
      ],
    );
  }
}
