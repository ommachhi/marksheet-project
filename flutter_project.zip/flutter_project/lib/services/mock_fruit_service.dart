import 'dart:async';

import '../models/fruit_model.dart';
import 'fruit_service_base.dart';

class MockFruitService implements FruitServiceBase {
  final List<FruitModel> _items = [
    FruitModel(
      id: '1',
      name: 'Apple',
      description: 'Crisp and sweet red fruit.',
      imageUrl: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce',
      nutrition: 'Rich in fiber and vitamin C',
      origin: 'USA',
      season: 'Fall',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    FruitModel(
      id: '2',
      name: 'Banana',
      description: 'Soft, sweet tropical fruit.',
      imageUrl: 'https://images.unsplash.com/photo-1574226516831-e1dff420e43e',
      nutrition: 'Potassium and vitamin B6',
      origin: 'Ecuador',
      season: 'Year-round',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  final StreamController<List<FruitModel>> _controller = StreamController<List<FruitModel>>.broadcast();

  MockFruitService() {
    _controller.add(List<FruitModel>.unmodifiable(_items));
  }

  @override
  Future<List<FruitModel>> getFruits() async {
    return List<FruitModel>.unmodifiable(_items);
  }

  @override
  Future<FruitModel?> getFruitById(String id) async {
    try {
      return _items.firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<String> createFruit(FruitModel fruit) async {
    final newId = DateTime.now().millisecondsSinceEpoch.toString();
    _items.add(fruit.copyWith(id: newId, createdAt: DateTime.now(), updatedAt: DateTime.now()));
    _controller.add(List<FruitModel>.unmodifiable(_items));
    return newId;
  }

  @override
  Future<void> updateFruit(String id, FruitModel fruit) async {
    final index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _items[index] = fruit.copyWith(id: id, updatedAt: DateTime.now());
      _controller.add(List<FruitModel>.unmodifiable(_items));
    }
  }

  @override
  Future<void> deleteFruit(String id) async {
    _items.removeWhere((e) => e.id == id);
    _controller.add(List<FruitModel>.unmodifiable(_items));
  }

  @override
  Stream<List<FruitModel>> getFruitsStream() => _controller.stream;
}


