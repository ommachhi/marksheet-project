import '../models/user_model.dart';

abstract class AuthServiceBase {
  Stream<UserModel?> get user;
  UserModel? get currentUser;
  Future<UserModel?> signInWithEmailAndPassword(String email, String password);
  Future<UserModel?> registerWithEmailAndPassword(String email, String password, String displayName);
  Future<void> signOut();
  Future<void> resetPassword(String email);
}


