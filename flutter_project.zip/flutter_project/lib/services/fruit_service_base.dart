import '../models/fruit_model.dart';

abstract class FruitServiceBase {
  Future<List<FruitModel>> getFruits();
  Future<FruitModel?> getFruitById(String id);
  Future<String> createFruit(FruitModel fruit);
  Future<void> updateFruit(String id, FruitModel fruit);
  Future<void> deleteFruit(String id);
  Stream<List<FruitModel>> getFruitsStream();
}


