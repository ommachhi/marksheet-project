import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/fruit_model.dart';
import 'fruit_service_base.dart';

class FruitService implements FruitServiceBase {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'fruits';

  @override
  Future<List<FruitModel>> getFruits() async {
    try {
      final QuerySnapshot snapshot = await _firestore
          .collection(_collection)
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs.map((doc) {
        return FruitModel.fromMap(doc.data() as Map<String, dynamic>, doc.id);
      }).toList();
    } catch (e) {
      throw Exception('Failed to fetch fruits: ${e.toString()}');
    }
  }

  @override
  Future<FruitModel?> getFruitById(String id) async {
    try {
      final DocumentSnapshot doc = await _firestore
          .collection(_collection)
          .doc(id)
          .get();

      if (doc.exists) {
        return FruitModel.fromMap(doc.data() as Map<String, dynamic>, doc.id);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to fetch fruit: ${e.toString()}');
    }
  }

  @override
  Future<String> createFruit(FruitModel fruit) async {
    try {
      final DocumentReference docRef = await _firestore
          .collection(_collection)
          .add(fruit.toMap());
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to create fruit: ${e.toString()}');
    }
  }

  @override
  Future<void> updateFruit(String id, FruitModel fruit) async {
    try {
      await _firestore
          .collection(_collection)
          .doc(id)
          .update(fruit.toMap());
    } catch (e) {
      throw Exception('Failed to update fruit: ${e.toString()}');
    }
  }

  @override
  Future<void> deleteFruit(String id) async {
    try {
      await _firestore
          .collection(_collection)
          .doc(id)
          .delete();
    } catch (e) {
      throw Exception('Failed to delete fruit: ${e.toString()}');
    }
  }

  @override
  Stream<List<FruitModel>> getFruitsStream() {
    return _firestore
        .collection(_collection)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return FruitModel.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
}

