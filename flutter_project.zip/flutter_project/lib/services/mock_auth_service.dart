import 'dart:async';

import '../models/user_model.dart';
import 'auth_service_base.dart';

class MockAuthService implements AuthServiceBase {
  final StreamController<UserModel?> _controller = StreamController<UserModel?>.broadcast();
  UserModel? _current;

  MockAuthService() {
    _controller.add(null);
  }

  @override
  Stream<UserModel?> get user => _controller.stream;

  @override
  UserModel? get currentUser => _current;

  @override
  Future<UserModel?> signInWithEmailAndPassword(String email, String password) async {
    _current = UserModel(id: 'mock-uid', email: email, displayName: 'Mock User');
    _controller.add(_current);
    return _current;
  }

  @override
  Future<UserModel?> registerWithEmailAndPassword(String email, String password, String displayName) async {
    _current = UserModel(id: 'mock-uid', email: email, displayName: displayName);
    _controller.add(_current);
    return _current;
  }

  @override
  Future<void> signOut() async {
    _current = null;
    _controller.add(null);
  }

  @override
  Future<void> resetPassword(String email) async {
    return; // no-op
  }
}


