class FruitModel {
  final String id;
  final String name;
  final String description;
  final String imageUrl;
  final String nutrition;
  final String origin;
  final String season;
  final DateTime createdAt;
  final DateTime updatedAt;

  FruitModel({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.nutrition,
    required this.origin,
    required this.season,
    required this.createdAt,
    required this.updatedAt,
  });

  factory FruitModel.fromMap(Map<String, dynamic> map, String id) {
    return FruitModel(
      id: id,
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      nutrition: map['nutrition'] ?? '',
      origin: map['origin'] ?? '',
      season: map['season'] ?? '',
      createdAt: map['createdAt']?.toDate() ?? DateTime.now(),
      updatedAt: map['updatedAt']?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'imageUrl': imageUrl,
      'nutrition': nutrition,
      'origin': origin,
      'season': season,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }

  FruitModel copyWith({
    String? id,
    String? name,
    String? description,
    String? imageUrl,
    String? nutrition,
    String? origin,
    String? season,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return FruitModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      imageUrl: imageUrl ?? this.imageUrl,
      nutrition: nutrition ?? this.nutrition,
      origin: origin ?? this.origin,
      season: season ?? this.season,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

