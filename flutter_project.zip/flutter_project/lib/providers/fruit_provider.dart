import 'package:flutter/material.dart';
import '../models/fruit_model.dart';
import '../services/fruit_service_base.dart';

class FruitProvider with ChangeNotifier {
  final FruitServiceBase _fruitService;
  List<FruitModel> _fruits = [];
  FruitModel? _selectedFruit;
  bool _isLoading = false;
  String? _error;

  FruitProvider(this._fruitService);

  List<FruitModel> get fruits => _fruits;
  FruitModel? get selectedFruit => _selectedFruit;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadFruits() async {
    _setLoading(true);
    _clearError();

    try {
      _fruits = await _fruitService.getFruits();
      _setLoading(false);
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
    }
  }

  Future<void> loadFruitById(String id) async {
    _setLoading(true);
    _clearError();

    try {
      _selectedFruit = await _fruitService.getFruitById(id);
      _setLoading(false);
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
    }
  }

  Future<bool> createFruit(FruitModel fruit) async {
    _setLoading(true);
    _clearError();

    try {
      await _fruitService.createFruit(fruit);
      await loadFruits(); // Refresh the list
      _setLoading(false);
      return true;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateFruit(String id, FruitModel fruit) async {
    _setLoading(true);
    _clearError();

    try {
      await _fruitService.updateFruit(id, fruit);
      await loadFruits(); // Refresh the list
      _setLoading(false);
      return true;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  Future<bool> deleteFruit(String id) async {
    _setLoading(true);
    _clearError();

    try {
      await _fruitService.deleteFruit(id);
      await loadFruits(); // Refresh the list
      _setLoading(false);
      return true;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  void setSelectedFruit(FruitModel? fruit) {
    _selectedFruit = fruit;
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }

  void clearError() {
    _clearError();
  }
}

