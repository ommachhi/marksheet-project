import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../providers/fruit_provider.dart';
import '../models/fruit_model.dart';

class AddEditFruitScreen extends StatefulWidget {
  final String? fruitId;

  const AddEditFruitScreen({super.key, this.fruitId});

  @override
  State<AddEditFruitScreen> createState() => _AddEditFruitScreenState();
}

class _AddEditFruitScreenState extends State<AddEditFruitScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _imageUrlController = TextEditingController();
  final _nutritionController = TextEditingController();
  final _originController = TextEditingController();
  final _seasonController = TextEditingController();

  bool get isEditing => widget.fruitId != null;

  @override
  void initState() {
    super.initState();
    if (isEditing) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadFruitData();
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _imageUrlController.dispose();
    _nutritionController.dispose();
    _originController.dispose();
    _seasonController.dispose();
    super.dispose();
  }

  Future<void> _loadFruitData() async {
    final fruitProvider = Provider.of<FruitProvider>(context, listen: false);
    await fruitProvider.loadFruitById(widget.fruitId!);
    
    if (fruitProvider.selectedFruit != null && mounted) {
      final fruit = fruitProvider.selectedFruit!;
      _nameController.text = fruit.name;
      _descriptionController.text = fruit.description;
      _imageUrlController.text = fruit.imageUrl;
      _nutritionController.text = fruit.nutrition;
      _originController.text = fruit.origin;
      _seasonController.text = fruit.season;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Fruit' : 'Add Fruit'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (isEditing) ...[
                Consumer<FruitProvider>(
                  builder: (context, fruitProvider, child) {
                    if (fruitProvider.isLoading) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return const SizedBox.shrink();
                  },
                ),
              ],
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Fruit Name',
                  prefixIcon: Icon(Icons.apple),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the fruit name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  prefixIcon: Icon(Icons.description),
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _imageUrlController,
                decoration: const InputDecoration(
                  labelText: 'Image URL',
                  prefixIcon: Icon(Icons.image),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an image URL';
                  }
                  final uri = Uri.tryParse(value.trim());
                  final isValid = uri != null && uri.hasScheme && uri.host.isNotEmpty;
                  if (!isValid) return 'Please enter a valid URL';
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nutritionController,
                decoration: const InputDecoration(
                  labelText: 'Nutrition Information',
                  prefixIcon: Icon(Icons.favorite),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter nutrition information';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _originController,
                decoration: const InputDecoration(
                  labelText: 'Origin',
                  prefixIcon: Icon(Icons.location_on),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the origin';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _seasonController,
                decoration: const InputDecoration(
                  labelText: 'Season',
                  prefixIcon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the season';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 32),
              Consumer<FruitProvider>(
                builder: (context, fruitProvider, child) {
                  return ElevatedButton(
                    onPressed: fruitProvider.isLoading ? null : _handleSubmit,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: fruitProvider.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            isEditing ? 'Update Fruit' : 'Add Fruit',
                            style: const TextStyle(fontSize: 16),
                          ),
                  );
                },
              ),
              Consumer<FruitProvider>(
                builder: (context, fruitProvider, child) {
                  if (fruitProvider.error != null) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: Text(
                        fruitProvider.error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleSubmit() async {
    if (_formKey.currentState!.validate()) {
      final fruitProvider = Provider.of<FruitProvider>(context, listen: false);
      
      final fruit = FruitModel(
        id: widget.fruitId ?? '',
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        imageUrl: _imageUrlController.text.trim(),
        nutrition: _nutritionController.text.trim(),
        origin: _originController.text.trim(),
        season: _seasonController.text.trim(),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      bool success;
      if (isEditing) {
        success = await fruitProvider.updateFruit(widget.fruitId!, fruit);
      } else {
        success = await fruitProvider.createFruit(fruit);
      }

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              isEditing ? 'Fruit updated successfully' : 'Fruit added successfully',
            ),
            backgroundColor: Colors.green,
          ),
        );
        context.go('/fruits');
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(fruitProvider.error ?? 'An error occurred'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}

