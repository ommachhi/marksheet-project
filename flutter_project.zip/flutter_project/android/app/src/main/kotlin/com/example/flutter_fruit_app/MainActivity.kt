package com.example.flutter_fruit_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()



